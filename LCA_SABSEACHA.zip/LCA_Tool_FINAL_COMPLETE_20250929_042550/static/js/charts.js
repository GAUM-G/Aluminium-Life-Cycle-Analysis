let mainChart = null;
let impactChart = null;
let productChart = null;
let currentDataType = 'comparison';
let currentChartType = 'pie';
let isLoading = false;

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, starting initialization...');
    
    // Ensure loading is hidden initially
    hideLoadingSpinner();
    
    setTimeout(() => {
        try {
            initializeCharts();
            setupEventListeners();
            loadInitialData();
        } catch (error) {
            console.error('Initialization error:', error);
            hideLoadingSpinner();
        }
    }, 200);
});

function showLoadingSpinner() {
    if (isLoading) return; // Prevent multiple calls
    
    isLoading = true;
    console.log('Showing loading spinner...');
    
    const loadingElement = document.getElementById('chartLoading');
    const chartElement = document.getElementById('mainChart');
    
    if (loadingElement) {
        loadingElement.classList.remove('loading-hidden');
        loadingElement.classList.add('loading-visible');
        loadingElement.style.display = 'block';
        loadingElement.style.visibility = 'visible';
    }
    
    if (chartElement) {
        chartElement.classList.add('chart-hidden');
    }
    
    // Fail-safe: Auto-hide after 8 seconds maximum [web:62]
    setTimeout(() => {
        if (isLoading) {
            console.log('Force hiding loading after 8 seconds timeout');
            hideLoadingSpinner();
        }
    }, 8000);
}

function hideLoadingSpinner() {
    isLoading = false;
    console.log('Hiding loading spinner...');
    
    const loadingElement = document.getElementById('chartLoading');
    const chartElement = document.getElementById('mainChart');
    
    if (loadingElement) {
        loadingElement.classList.remove('loading-visible');
        loadingElement.classList.add('loading-hidden');
        loadingElement.style.display = 'none';
        loadingElement.style.visibility = 'hidden';
    }
    
    if (chartElement) {
        chartElement.classList.remove('chart-hidden');
    }
}

function initializeCharts() {
    console.log('Initializing charts...');
    
    try {
        // Main chart initialization
        const mainCtx = document.getElementById('mainChart');
        if (!mainCtx) {
            throw new Error('Main chart canvas not found');
        }
        
        mainChart = new Chart(mainCtx.getContext('2d'), {
            type: 'pie',
            data: {
                labels: ['Loading...'],
                datasets: [{
                    data: [1],
                    backgroundColor: ['#e9ecef'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 20, usePointStyle: true }
                    }
                },
                animation: {
                    duration: 500, // Shorter animation
                    onComplete: function() {
                        console.log('Main chart animation complete');
                    }
                }
            }
        });
        
        // Impact chart
        const impactCtx = document.getElementById('impactChart');
        if (!impactCtx) {
            throw new Error('Impact chart canvas not found');
        }
        
        impactChart = new Chart(impactCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['CO2 Emissions', 'Energy Usage', 'Water Usage', 'Cost'],
                datasets: [{
                    label: 'Conventional',
                    data: [0, 0, 0, 0],
                    backgroundColor: 'rgba(255, 99, 132, 0.6)'
                }, {
                    label: 'Recycled',
                    data: [0, 0, 0, 0],
                    backgroundColor: 'rgba(54, 162, 235, 0.6)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 500 },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        
        // Product chart
        const productCtx = document.getElementById('productChart');
        if (!productCtx) {
            throw new Error('Product chart canvas not found');
        }
        
        productChart = new Chart(productCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Loading...'],
                datasets: [{
                    data: [1],
                    backgroundColor: ['#e9ecef']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 500 },
                plugins: {
                    legend: { position: 'right' }
                }
            }
        });
        
        console.log('Charts initialized successfully');
        
    } catch (error) {
        console.error('Error initializing charts:', error);
        showError('Failed to initialize charts: ' + error.message);
        hideLoadingSpinner();
    }
}

function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    const eventHandlers = [
        ['showConventional', () => {
            setActiveButton('data', 'showConventional');
            currentDataType = 'conventional';
            updateChartTitle('Conventional Products Analysis');
            loadChartData();
        }],
        ['showRecycled', () => {
            setActiveButton('data', 'showRecycled');
            currentDataType = 'recycled';
            updateChartTitle('Recycled Products Analysis');
            loadChartData();
        }],
        ['showComparison', () => {
            setActiveButton('data', 'showComparison');
            currentDataType = 'comparison';
            updateChartTitle('Products Comparison Analysis');
            loadComparisonData();
        }],
        ['chartTypePie', () => {
            setActiveButton('chart', 'chartTypePie');
            currentChartType = 'pie';
            updateChartType();
        }],
        ['chartTypeBar', () => {
            setActiveButton('chart', 'chartTypeBar');
            currentChartType = 'bar';
            updateChartType();
        }],
        ['chartTypeLine', () => {
            setActiveButton('chart', 'chartTypeLine');
            currentChartType = 'line';
            updateChartType();
        }]
    ];
    
    eventHandlers.forEach(([id, handler]) => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('click', handler);
        } else {
            console.warn(`Element with id '${id}' not found`);
        }
    });
}

function setActiveButton(group, activeId) {
    const buttons = {
        data: ['showConventional', 'showRecycled', 'showComparison'],
        chart: ['chartTypePie', 'chartTypeBar', 'chartTypeLine']
    };
    
    buttons[group]?.forEach(id => {
        document.getElementById(id)?.classList.remove('active');
    });
    
    document.getElementById(activeId)?.classList.add('active');
}

async function loadInitialData() {
    console.log('Loading initial data...');
    showLoadingSpinner();
    
    try {
        // Use Promise.allSettled with individual timeouts [web:62]
        const dataPromises = [
            createTimeoutPromise(loadComparisonDataSafe(), 5000, 'comparison data'),
            createTimeoutPromise(loadProductDistributionSafe(), 5000, 'product data')
        ];
        
        const results = await Promise.allSettled(dataPromises);
        
        results.forEach((result, index) => {
            if (result.status === 'rejected') {
                console.error(`Promise ${index} failed:`, result.reason);
            }
        });
        
        console.log('Initial data loading completed');
        
    } catch (error) {
        console.error('Error loading initial data:', error);
        showError('Failed to load initial data');
    } finally {
        // Always hide loading after a delay [web:62]
        setTimeout(() => {
            console.log('Force hiding loading after data load attempt');
            hideLoadingSpinner();
        }, 1000);
    }
}

function createTimeoutPromise(promise, timeout, name) {
    return Promise.race([
        promise,
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`${name} timeout after ${timeout}ms`)), timeout)
        )
    ]);
}

async function loadComparisonDataSafe() {
    try {
        const response = await fetch('/api/comparison-data');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        // Update charts in next tick to avoid blocking
        setTimeout(() => updateChartsWithData(data), 0);
        
    } catch (error) {
        console.error('Comparison data load failed:', error);
        // Set placeholder data
        setTimeout(() => {
            if (mainChart) {
                mainChart.data.labels = ['No Data'];
                mainChart.data.datasets[0].data = [1];
                mainChart.update('none');
            }
        }, 0);
    }
}

async function loadProductDistributionSafe() {
    try {
        const response = await fetch('/api/product-distribution');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        // Update chart in next tick
        setTimeout(() => {
            if (productChart) {
                if (data.labels && data.labels.length > 0) {
                    productChart.data.labels = data.labels;
                    productChart.data.datasets[0].data = data.counts;
                } else {
                    productChart.data.labels = ['No Products'];
                    productChart.data.datasets[0].data = [1];
                }
                productChart.update('none');
            }
        }, 0);
        
    } catch (error) {
        console.error('Product distribution load failed:', error);
    }
}

function updateChartsWithData(data) {
    try {
        const totalConventional = data.conventional?.count || 0;
        const totalRecycled = data.recycled?.count || 0;
        
        // Update main chart
        if (mainChart) {
            if (totalConventional === 0 && totalRecycled === 0) {
                mainChart.data.labels = ['No Data Available'];
                mainChart.data.datasets[0].data = [1];
                mainChart.data.datasets[0].backgroundColor = ['#e9ecef'];
            } else {
                mainChart.data.labels = ['Conventional', 'Recycled'];
                mainChart.data.datasets[0].data = [totalConventional, totalRecycled];
                mainChart.data.datasets[0].backgroundColor = ['#FF6384', '#36A2EB'];
            }
            mainChart.update('none');
        }
        
        // Update impact chart
        if (impactChart && data.conventional && data.recycled) {
            impactChart.data.datasets[0].data = [
                data.conventional.avg_co2 || 0,
                data.conventional.avg_energy || 0,
                (data.conventional.avg_cost || 0) / 100,
                data.conventional.total_co2 || 0
            ];
            
            impactChart.data.datasets[1].data = [
                data.recycled.avg_co2 || 0,
                data.recycled.avg_energy || 0,
                (data.recycled.avg_cost || 0) / 100,
                data.recycled.total_co2 || 0
            ];
            
            impactChart.update('none');
        }
        
        // Update statistics
        updateComparisonStatistics(data);
        
    } catch (error) {
        console.error('Error updating charts with data:', error);
    }
}

// Simplified remaining functions
async function loadChartData() {
    if (!mainChart) return;
    
    showLoadingSpinner();
    
    try {
        const response = await fetch(`/api/chart-data/${currentDataType}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        setTimeout(() => {
            if (data.route_distribution?.labels?.length > 0) {
                mainChart.data.labels = data.route_distribution.labels;
                mainChart.data.datasets[0].data = data.route_distribution.data;
            } else {
                mainChart.data.labels = ['No Data'];
                mainChart.data.datasets[0].data = [1];
            }
            
            mainChart.update('none');
            updateStatistics(data);
        }, 0);
        
    } catch (error) {
        console.error('Error loading chart data:', error);
        showError('Failed to load chart data');
    } finally {
        setTimeout(() => hideLoadingSpinner(), 500);
    }
}

async function loadComparisonData() {
    showLoadingSpinner();
    
    try {
        await loadComparisonDataSafe();
    } finally {
        setTimeout(() => hideLoadingSpinner(), 500);
    }
}

function updateChartType() {
    if (!mainChart) return;
    
    try {
        const currentData = {
            labels: [...mainChart.data.labels],
            data: [...mainChart.data.datasets[0].data]
        };
        
        mainChart.destroy();
        
        const ctx = document.getElementById('mainChart').getContext('2d');
        const config = createChartConfig(currentChartType, currentData);
        
        mainChart = new Chart(ctx, config);
        
    } catch (error) {
        console.error('Error updating chart type:', error);
        showError('Failed to update chart type');
    }
}

function createChartConfig(type, data) {
    const baseConfig = {
        type: type,
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 500 },
            plugins: {
                legend: { position: type === 'pie' ? 'bottom' : 'top' }
            }
        }
    };
    
    if (type === 'bar' || type === 'line') {
        baseConfig.options.scales = { y: { beginAtZero: true } };
    }
    
    if (type === 'line') {
        baseConfig.data.datasets[0].fill = false;
        baseConfig.data.datasets[0].borderColor = '#36A2EB';
        baseConfig.options.elements = { line: { tension: 0.4 } };
    }
    
    return baseConfig;
}

function updateChartTitle(title) {
    const titleElement = document.getElementById('chartTitle');
    if (titleElement) titleElement.textContent = title;
}

function updateStatistics(data) {
    const totalElement = document.getElementById('totalAssessments');
    if (totalElement && data.total_assessments !== undefined) {
        totalElement.textContent = data.total_assessments;
    }
}

function updateComparisonStatistics(data) {
    try {
        const elements = {
            total: document.getElementById('totalAssessments'),
            co2: document.getElementById('co2Reduction'),
            energy: document.getElementById('energySavings'),
            cost: document.getElementById('costImpact')
        };
        
        if (elements.total) {
            const total = (data.conventional?.count || 0) + (data.recycled?.count || 0);
            elements.total.textContent = total;
        }
        
        if (elements.co2 && data.improvement) {
            elements.co2.textContent = `${data.improvement.co2_reduction || 0}%`;
        }
        
        if (elements.energy && data.improvement) {
            elements.energy.textContent = `${data.improvement.energy_reduction || 0}%`;
        }
        
        if (elements.cost && data.improvement) {
            const costDiff = data.improvement.cost_difference || 0;
            elements.cost.textContent = `$${costDiff > 0 ? '+' : ''}${costDiff}`;
        }
    } catch (error) {
        console.error('Error updating statistics:', error);
    }
}

function showError(message) {
    console.error(message);
    
    const existingErrors = document.querySelectorAll('.error-notification');
    existingErrors.forEach(error => error.remove());
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger error-notification';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${message}`;
    errorDiv.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;max-width:400px;padding:10px;';
    
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.style.opacity = '0';
            errorDiv.style.transition = 'opacity 0.3s';
            setTimeout(() => errorDiv.remove(), 300);
        }
    }, 5000);
    
    // Ensure loading is hidden when error occurs
    hideLoadingSpinner();
}

function downloadReport(reportType) {
    try {
        const button = event.target.closest('button');
        const originalHTML = button.innerHTML;
        
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
        button.disabled = true;
        
        const link = document.createElement('a');
        link.href = `/download-visualization-report/${reportType}`;
        link.download = '';
        link.click();
        
        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.disabled = false;
        }, 3000);
        
    } catch (error) {
        console.error('Error downloading report:', error);
        showError('Failed to download report');
    }
}

// Emergency cleanup after 15 seconds
setTimeout(() => {
    if (isLoading) {
        console.log('Emergency loading cleanup after 15 seconds');
        hideLoadingSpinner();
    }
}, 15000);

console.log('Enhanced Chart.js script loaded successfully');
