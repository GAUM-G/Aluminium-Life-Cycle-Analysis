# LCA Tool - AI-Driven Life Cycle Assessment

## Problem Statement
AI-Driven Life Cycle Assessment (LCA) Tool for Advancing Circularity and Sustainability in Metallurgy and Mining

## Features
- User Authentication System
- AI-Powered LCA Analysis  
- Route Comparison (Conventional vs Recycled)
- Custom Product Specifications
- Interactive Dashboard with Metrics
- PDF Report Generation
- Environmental Impact Visualization

## Installation
1. Extract project files
2. Install dependencies: `pip install -r requirements.txt`
3. Install and start MongoDB
4. Set environment variables in `.env`
5. Run: `python app.py`
6. Access: `http://localhost:5000`

## Technology Stack
- Backend: Python Flask
- Database: MongoDB
- Frontend: HTML5, CSS3, JavaScript, Chart.js
- AI/ML: Scikit-learn, NumPy, Pandas
- PDF Generation: ReportLab

## License
MIT License