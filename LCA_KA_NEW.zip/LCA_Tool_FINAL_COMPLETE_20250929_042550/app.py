from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash, send_file
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import json
import pandas as pd
import numpy as np
from bson import ObjectId
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import pickle
import warnings
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill

warnings.filterwarnings('ignore')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['MONGO_URI'] = 'mongodb+srv://lca_admin:iy423WBcKxhZmAcP@lca-cluster.een843p.mongodb.net/lca_tool?retryWrites=true&w=majority'

print(f"🔍 Using MongoDB URI: {app.config['MONGO_URI']}")

# Initialize MongoDB
mongo = PyMongo(app)

# LCA Calculator with AI/ML capabilities
class LCACalculator:
    def __init__(self):
        self.emission_factors = {
            'aluminium_primary': 11.5,  # kg CO2/kg Al
            'aluminium_recycled': 0.6,   # kg CO2/kg Al
            'copper_primary': 4.2,      # kg CO2/kg Cu
            'copper_recycled': 1.1,     # kg CO2/kg Cu
        }

    def calculate_lca(self, product_data):
        """Calculate LCA metrics using AI/ML models"""
        try:
            # Extract parameters
            product_type = product_data.get('product', 'aluminium_pipe')
            route = product_data.get('route', 'conventional')
            units = float(product_data.get('units', 100))
            energy_source = product_data.get('energy_source', 'non_renewable')

            # Material properties
            if 'aluminium' in product_type or product_type == 'custom':
                material_density = float(product_data.get('material_density', 2700))  # kg/m³
                if route == 'recycled':
                    emission_factor = self.emission_factors['aluminium_recycled']
                else:
                    emission_factor = self.emission_factors['aluminium_primary']
            else:
                material_density = 8960  # kg/m³ for copper
                if route == 'recycled':
                    emission_factor = self.emission_factors['copper_recycled']
                else:
                    emission_factor = self.emission_factors['copper_primary']

            # Volume calculation based on product type
            if product_type == 'aluminium_pipe':
                outer_radius = float(product_data.get('outer_radius', 0.05))
                inner_radius = float(product_data.get('inner_radius', 0.04))
                length = float(product_data.get('length', 1.0))
                volume = 3.14159 * (outer_radius**2 - inner_radius**2) * length
            elif product_type == 'aluminium_sheet':
                length = float(product_data.get('length', 1.0))
                width = float(product_data.get('width', 0.5))
                thickness = float(product_data.get('thickness', 0.01))
                volume = length * width * thickness
            else:  # custom product
                length = float(product_data.get('length', 1000)) / 1000  # convert mm to m
                width = float(product_data.get('width', 500)) / 1000
                thickness = float(product_data.get('thickness', 10)) / 1000
                volume = length * width * thickness

            # Core calculations
            material_mass = volume * material_density * units

            # Energy calculations with source multiplier
            energy_multiplier = 1.2 if energy_source == 'non_renewable' else 0.8
            energy_consumption = material_mass * 15 * energy_multiplier  # kWh

            # Environmental impact calculations
            water_usage = material_mass * 8.5  # L/kg
            co2_emissions = material_mass * emission_factor * energy_multiplier
            waste_generation = material_mass * 0.05  # 5% waste
            transport_impact = material_mass * 0.1 * float(product_data.get('transport_distance', 500)) / 500

            # Economic calculations
            base_cost_per_kg = 150 if route == 'conventional' else 120
            manufacturing_cost = material_mass * base_cost_per_kg

            # Circularity metrics
            recycled_content = 90 if route == 'recycled' else 10  # %
            recyclability = 95 if 'aluminium' in product_type else 85  # %

            # Quality assessment
            quality_score = float(product_data.get('quality_score', 85.0))

            # Compile results
            results = {
                'co2_emissions': round(co2_emissions, 2),
                'energy_consumption': round(energy_consumption, 2),
                'water_usage': round(water_usage, 2),
                'material_mass': round(material_mass, 2),
                'manufacturing_cost': round(manufacturing_cost, 2),
                'recycled_content': recycled_content,
                'recyclability': recyclability,
                'quality_score': quality_score,
                'waste_generation': round(waste_generation, 2),
                'transport_impact': round(transport_impact, 2),
                'end_of_life_impact': round(co2_emissions * 0.1, 2)
            }

            # Generate AI recommendations
            recommendations = self.generate_recommendations(product_data, results)
            results['recommendations'] = recommendations

            return results

        except Exception as e:
            print(f"Error in LCA calculation: {str(e)}")
            return None

    def generate_recommendations(self, product_data, results):
        """Generate AI-powered recommendations for circularity improvement"""
        recommendations = []

        route = product_data.get('route', 'conventional')
        energy_source = product_data.get('energy_source', 'non_renewable')
        end_of_life = product_data.get('end_of_life', 'landfill')

        # Material sourcing recommendation
        if route == 'conventional':
            recommendations.append({
                'category': 'Material Sourcing',
                'suggestion': 'Switch to recycled aluminum to reduce CO2 emissions by up to 94%',
                'impact': 'High',
                'savings': f"{results['co2_emissions'] * 0.94:.1f} kg CO2"
            })

        # Energy source recommendation
        if energy_source == 'non_renewable':
            recommendations.append({
                'category': 'Energy Source',
                'suggestion': 'Transition to renewable energy sources to reduce environmental impact',
                'impact': 'Medium',
                'savings': f"{results['energy_consumption'] * 0.3:.1f} kWh"
            })

        # End-of-life recommendation
        if end_of_life == 'landfill':
            recommendations.append({
                'category': 'End-of-Life',
                'suggestion': 'Implement recycling programs to achieve circular economy benefits',
                'impact': 'High',
                'savings': 'Up to 95% material recovery'
            })

        # Quality improvement recommendation
        if results['quality_score'] < 80:
            recommendations.append({
                'category': 'Quality Improvement',
                'suggestion': 'Enhance manufacturing processes to improve product longevity',
                'impact': 'Medium',
                'savings': 'Extended product lifecycle'
            })

        return recommendations

# Initialize LCA Calculator
lca_calculator = LCACalculator()

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('auth/login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        user = mongo.db.users.find_one({'email': email})

        if user and check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])
            session['username'] = user['username']
            return jsonify({'success': True, 'message': 'Login successful'})
        else:
            return jsonify({'success': False, 'message': 'Invalid credentials'})

    return render_template('auth/login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')

        if mongo.db.users.find_one({'email': email}):
            return jsonify({'success': False, 'message': 'Email already registered'})

        hashed_password = generate_password_hash(password)
        user_data = {
            'username': username,
            'email': email,
            'password': hashed_password,
            'created_at': datetime.utcnow()
        }

        result = mongo.db.users.insert_one(user_data)
        session['user_id'] = str(result.inserted_id)
        session['username'] = username

        return jsonify({'success': True, 'message': 'Registration successful'})

    return render_template('auth/signup.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    total_assessments = mongo.db.assessments.count_documents({'user_id': user_id})

    recent_assessments = list(mongo.db.assessments.find({'user_id': user_id})
                             .sort('created_at', -1).limit(5))

    co2_savings = sum(assessment.get('results', {}).get('co2_emissions', 0) * 0.1 
                     for assessment in recent_assessments if assessment.get('input_data', {}).get('route') == 'recycled')

    stats = {
        'total_assessments': total_assessments,
        'co2_savings': round(co2_savings, 1),
        'active_projects': len(recent_assessments),
        'cost_efficiency': 85.2
    }

    return render_template('dashboard/index.html', 
                         username=session['username'], 
                         stats=stats, 
                         recent_assessments=recent_assessments)

# NEW VISUALIZATION ROUTES
@app.route('/visualization')
def visualization():
    """New visualization dashboard page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard/visualization.html', username=session['username'])

@app.route('/api/chart-data/<data_type>')
def get_chart_data(data_type):
    """Get data for conventional vs recycled comparison charts"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        user_id = session['user_id']
        
        if data_type == 'conventional':
            # Query for conventional assessments
            assessments = list(mongo.db.assessments.find({
                'user_id': user_id,
                'input_data.route': 'conventional'
            }))
        elif data_type == 'recycled':
            # Query for recycled assessments
            assessments = list(mongo.db.assessments.find({
                'user_id': user_id,
                'input_data.route': 'recycled'
            }))
        else:
            # Get all assessments for comparison
            assessments = list(mongo.db.assessments.find({'user_id': user_id}))
        
        # Process data for charts
        processed_data = process_assessment_data(assessments)
        return jsonify(processed_data)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/comparison-data')
def get_comparison_data():
    """Get comparative data for conventional vs recycled"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        user_id = session['user_id']
        
        conventional_assessments = list(mongo.db.assessments.find({
            'user_id': user_id,
            'input_data.route': 'conventional'
        }))
        
        recycled_assessments = list(mongo.db.assessments.find({
            'user_id': user_id,
            'input_data.route': 'recycled'
        }))
        
        # Calculate aggregated metrics
        conventional_metrics = calculate_aggregate_metrics(conventional_assessments)
        recycled_metrics = calculate_aggregate_metrics(recycled_assessments)
        
        comparison = {
            'conventional': conventional_metrics,
            'recycled': recycled_metrics,
            'improvement': {
                'co2_reduction': round(((conventional_metrics['avg_co2'] - recycled_metrics['avg_co2']) 
                                      / conventional_metrics['avg_co2'] * 100) if conventional_metrics['avg_co2'] > 0 else 0, 1),
                'energy_reduction': round(((conventional_metrics['avg_energy'] - recycled_metrics['avg_energy']) 
                                         / conventional_metrics['avg_energy'] * 100) if conventional_metrics['avg_energy'] > 0 else 0, 1),
                'cost_difference': round(recycled_metrics['avg_cost'] - conventional_metrics['avg_cost'], 2)
            }
        }
        
        return jsonify(comparison)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/product-distribution')
def get_product_distribution():
    """Get product type distribution data"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        user_id = session['user_id']
        
        pipeline = [
            {'$match': {'user_id': user_id}},
            {'$group': {
                '_id': '$input_data.product',
                'count': {'$sum': 1},
                'avg_co2': {'$avg': '$results.co2_emissions'},
                'avg_cost': {'$avg': '$results.manufacturing_cost'}
            }}
        ]
        
        result = list(mongo.db.assessments.aggregate(pipeline))
        
        processed_data = {
            'labels': [item['_id'] for item in result],
            'counts': [item['count'] for item in result],
            'co2_data': [round(item['avg_co2'], 2) for item in result],
            'cost_data': [round(item['avg_cost'], 2) for item in result]
        }
        
        return jsonify(processed_data)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download-visualization-report/<report_type>')
def download_visualization_report(report_type):
    """Generate and download visualization reports"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    try:
        if report_type == 'pdf':
            return generate_comprehensive_pdf_report()
        elif report_type == 'excel':
            return generate_comprehensive_excel_report()
        else:
            flash('Invalid report type', 'error')
            return redirect(url_for('visualization'))
    
    except Exception as e:
        flash(f'Error generating report: {str(e)}', 'error')
        return redirect(url_for('visualization'))

def process_assessment_data(assessments):
    """Process assessment data for visualization"""
    if not assessments:
        return {'labels': [], 'data': [], 'total': 0}
    
    # Group by route type
    route_counts = {}
    product_counts = {}
    total_co2 = 0
    total_energy = 0
    
    for assessment in assessments:
        route = assessment.get('input_data', {}).get('route', 'unknown')
        product = assessment.get('input_data', {}).get('product', 'unknown')
        results = assessment.get('results', {})
        
        # Count by route
        route_counts[route] = route_counts.get(route, 0) + 1
        
        # Count by product
        product_counts[product] = product_counts.get(product, 0) + 1
        
        # Sum totals
        total_co2 += results.get('co2_emissions', 0)
        total_energy += results.get('energy_consumption', 0)
    
    return {
        'route_distribution': {
            'labels': list(route_counts.keys()),
            'data': list(route_counts.values())
        },
        'product_distribution': {
            'labels': list(product_counts.keys()),
            'data': list(product_counts.values())
        },
        'total_assessments': len(assessments),
        'total_co2': round(total_co2, 2),
        'total_energy': round(total_energy, 2)
    }

def calculate_aggregate_metrics(assessments):
    """Calculate aggregate metrics for a set of assessments"""
    if not assessments:
        return {
            'count': 0,
            'avg_co2': 0,
            'avg_energy': 0,
            'avg_cost': 0,
            'total_co2': 0,
            'total_energy': 0,
            'total_cost': 0
        }
    
    total_co2 = sum(a.get('results', {}).get('co2_emissions', 0) for a in assessments)
    total_energy = sum(a.get('results', {}).get('energy_consumption', 0) for a in assessments)
    total_cost = sum(a.get('results', {}).get('manufacturing_cost', 0) for a in assessments)
    count = len(assessments)
    
    return {
        'count': count,
        'avg_co2': round(total_co2 / count, 2) if count > 0 else 0,
        'avg_energy': round(total_energy / count, 2) if count > 0 else 0,
        'avg_cost': round(total_cost / count, 2) if count > 0 else 0,
        'total_co2': round(total_co2, 2),
        'total_energy': round(total_energy, 2),
        'total_cost': round(total_cost, 2)
    }

def generate_comprehensive_excel_report():
    """Generate comprehensive Excel report with multiple sheets"""
    user_id = session['user_id']
    
    # Get all user assessments
    assessments = list(mongo.db.assessments.find({'user_id': user_id}))
    
    if not assessments:
        flash('No data available for report generation', 'warning')
        return redirect(url_for('visualization'))
    
    # Create Excel file in memory
    output = io.BytesIO()
    workbook = openpyxl.Workbook()
    
    # Remove default sheet
    workbook.remove(workbook.active)
    
    # Create summary sheet
    summary_sheet = workbook.create_sheet("Summary")
    
    # Header styling
    header_font = Font(bold=True, size=12)
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    
    # Summary data
    conventional_assessments = [a for a in assessments if a.get('input_data', {}).get('route') == 'conventional']
    recycled_assessments = [a for a in assessments if a.get('input_data', {}).get('route') == 'recycled']
    
    conventional_metrics = calculate_aggregate_metrics(conventional_assessments)
    recycled_metrics = calculate_aggregate_metrics(recycled_assessments)
    
    # Write summary data
    summary_data = [
        ['Metric', 'Conventional', 'Recycled', 'Improvement'],
        ['Total Assessments', conventional_metrics['count'], recycled_metrics['count'], ''],
        ['Average CO2 Emissions (kg)', conventional_metrics['avg_co2'], recycled_metrics['avg_co2'], 
         f"{((conventional_metrics['avg_co2'] - recycled_metrics['avg_co2']) / conventional_metrics['avg_co2'] * 100) if conventional_metrics['avg_co2'] > 0 else 0:.1f}%"],
        ['Average Energy (kWh)', conventional_metrics['avg_energy'], recycled_metrics['avg_energy'],
         f"{((conventional_metrics['avg_energy'] - recycled_metrics['avg_energy']) / conventional_metrics['avg_energy'] * 100) if conventional_metrics['avg_energy'] > 0 else 0:.1f}%"],
        ['Average Cost ($)', conventional_metrics['avg_cost'], recycled_metrics['avg_cost'],
         f"{recycled_metrics['avg_cost'] - conventional_metrics['avg_cost']:.2f}"],
    ]
    
    for row_num, row_data in enumerate(summary_data, 1):
        for col_num, cell_data in enumerate(row_data, 1):
            cell = summary_sheet.cell(row=row_num, column=col_num, value=cell_data)
            if row_num == 1:  # Header row
                cell.font = header_font
                cell.fill = header_fill
    
    # Create detailed assessments sheet
    details_sheet = workbook.create_sheet("All Assessments")
    
    # Headers for detailed data
    headers = ['Date', 'Product', 'Route', 'CO2 Emissions', 'Energy Consumption', 
               'Water Usage', 'Manufacturing Cost', 'Quality Score', 'Recycled Content']
    
    for col_num, header in enumerate(headers, 1):
        cell = details_sheet.cell(row=1, column=col_num, value=header)
        cell.font = header_font
        cell.fill = header_fill
    
    # Write detailed data
    for row_num, assessment in enumerate(assessments, 2):
        input_data = assessment.get('input_data', {})
        results = assessment.get('results', {})
        
        row_data = [
            assessment.get('created_at', '').strftime('%Y-%m-%d') if assessment.get('created_at') else '',
            input_data.get('product', ''),
            input_data.get('route', ''),
            results.get('co2_emissions', 0),
            results.get('energy_consumption', 0),
            results.get('water_usage', 0),
            results.get('manufacturing_cost', 0),
            results.get('quality_score', 0),
            results.get('recycled_content', 0)
        ]
        
        for col_num, cell_data in enumerate(row_data, 1):
            details_sheet.cell(row=row_num, column=col_num, value=cell_data)
    
    # Create conventional data sheet
    if conventional_assessments:
        conv_sheet = workbook.create_sheet("Conventional")
        
        # Add headers
        for col_num, header in enumerate(headers, 1):
            cell = conv_sheet.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
        
        # Add data
        for row_num, assessment in enumerate(conventional_assessments, 2):
            input_data = assessment.get('input_data', {})
            results = assessment.get('results', {})
            
            row_data = [
                assessment.get('created_at', '').strftime('%Y-%m-%d') if assessment.get('created_at') else '',
                input_data.get('product', ''),
                input_data.get('route', ''),
                results.get('co2_emissions', 0),
                results.get('energy_consumption', 0),
                results.get('water_usage', 0),
                results.get('manufacturing_cost', 0),
                results.get('quality_score', 0),
                results.get('recycled_content', 0)
            ]
            
            for col_num, cell_data in enumerate(row_data, 1):
                conv_sheet.cell(row=row_num, column=col_num, value=cell_data)
    
    # Create recycled data sheet
    if recycled_assessments:
        recyc_sheet = workbook.create_sheet("Recycled")
        
        # Add headers
        for col_num, header in enumerate(headers, 1):
            cell = recyc_sheet.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
        
        # Add data
        for row_num, assessment in enumerate(recycled_assessments, 2):
            input_data = assessment.get('input_data', {})
            results = assessment.get('results', {})
            
            row_data = [
                assessment.get('created_at', '').strftime('%Y-%m-%d') if assessment.get('created_at') else '',
                input_data.get('product', ''),
                input_data.get('route', ''),
                results.get('co2_emissions', 0),
                results.get('energy_consumption', 0),
                results.get('water_usage', 0),
                results.get('manufacturing_cost', 0),
                results.get('quality_score', 0),
                results.get('recycled_content', 0)
            ]
            
            for col_num, cell_data in enumerate(row_data, 1):
                recyc_sheet.cell(row=row_num, column=col_num, value=cell_data)
    
    # Save workbook
    workbook.save(output)
    output.seek(0)
    
    return send_file(
        output,
        as_attachment=True,
        download_name=f'LCA_Comprehensive_Report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

def generate_comprehensive_pdf_report():
    """Generate comprehensive PDF report with visualizations"""
    user_id = session['user_id']
    assessments = list(mongo.db.assessments.find({'user_id': user_id}))
    
    if not assessments:
        flash('No data available for report generation', 'warning')
        return redirect(url_for('visualization'))
    
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    
    # Header
    p.setFont("Helvetica-Bold", 20)
    p.drawString(50, 750, "LCA Tool - Comprehensive Environmental Report")
    
    p.setFont("Helvetica", 12)
    p.drawString(50, 720, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    p.drawString(50, 700, f"User: {session['username']}")
    
    # Summary Statistics
    conventional_assessments = [a for a in assessments if a.get('input_data', {}).get('route') == 'conventional']
    recycled_assessments = [a for a in assessments if a.get('input_data', {}).get('route') == 'recycled']
    
    conventional_metrics = calculate_aggregate_metrics(conventional_assessments)
    recycled_metrics = calculate_aggregate_metrics(recycled_assessments)
    
    y_pos = 660
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, y_pos, "Executive Summary")
    y_pos -= 30
    
    p.setFont("Helvetica", 12)
    summary_data = [
        f"Total Assessments: {len(assessments)}",
        f"Conventional Products: {conventional_metrics['count']}",
        f"Recycled Products: {recycled_metrics['count']}",
        "",
        "Environmental Impact Comparison:",
        f"  • CO2 Emissions Reduction: {((conventional_metrics['avg_co2'] - recycled_metrics['avg_co2']) / conventional_metrics['avg_co2'] * 100) if conventional_metrics['avg_co2'] > 0 else 0:.1f}%",
        f"  • Energy Consumption Reduction: {((conventional_metrics['avg_energy'] - recycled_metrics['avg_energy']) / conventional_metrics['avg_energy'] * 100) if conventional_metrics['avg_energy'] > 0 else 0:.1f}%",
        f"  • Cost Difference: ${recycled_metrics['avg_cost'] - conventional_metrics['avg_cost']:.2f}",
    ]
    
    for line in summary_data:
        p.drawString(50, y_pos, line)
        y_pos -= 18
    
    # Detailed Metrics
    y_pos -= 20
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, y_pos, "Detailed Metrics")
    y_pos -= 30
    
    # Conventional metrics
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y_pos, "Conventional Products:")
    y_pos -= 20
    
    p.setFont("Helvetica", 11)
    conv_metrics = [
        f"Average CO2 Emissions: {conventional_metrics['avg_co2']} kg",
        f"Average Energy Consumption: {conventional_metrics['avg_energy']} kWh",
        f"Average Manufacturing Cost: ${conventional_metrics['avg_cost']}",
        f"Total CO2 Emissions: {conventional_metrics['total_co2']} kg"
    ]
    
    for metric in conv_metrics:
        p.drawString(70, y_pos, metric)
        y_pos -= 15
    
    y_pos -= 10
    
    # Recycled metrics
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y_pos, "Recycled Products:")
    y_pos -= 20
    
    p.setFont("Helvetica", 11)
    recyc_metrics = [
        f"Average CO2 Emissions: {recycled_metrics['avg_co2']} kg",
        f"Average Energy Consumption: {recycled_metrics['avg_energy']} kWh",
        f"Average Manufacturing Cost: ${recycled_metrics['avg_cost']}",
        f"Total CO2 Emissions: {recycled_metrics['total_co2']} kg"
    ]
    
    for metric in recyc_metrics:
        p.drawString(70, y_pos, metric)
        y_pos -= 15
    
    # Recent Assessments
    if y_pos < 200:
        p.showPage()
        y_pos = 750
    
    y_pos -= 20
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, y_pos, "Recent Assessments")
    y_pos -= 20
    
    p.setFont("Helvetica", 10)
    recent = sorted(assessments, key=lambda x: x.get('created_at', datetime.min), reverse=True)[:10]
    
    for assessment in recent:
        if y_pos < 100:
            p.showPage()
            y_pos = 750
        
        input_data = assessment.get('input_data', {})
        results = assessment.get('results', {})
        date_str = assessment.get('created_at', '').strftime('%Y-%m-%d') if assessment.get('created_at') else 'Unknown'
        
        p.drawString(50, y_pos, f"{date_str} | {input_data.get('product', 'Unknown')} ({input_data.get('route', 'Unknown')})")
        y_pos -= 12
        p.drawString(70, y_pos, f"CO2: {results.get('co2_emissions', 0)} kg | Energy: {results.get('energy_consumption', 0)} kWh | Cost: ${results.get('manufacturing_cost', 0)}")
        y_pos -= 20
    
    p.save()
    buffer.seek(0)
    
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f'LCA_Comprehensive_Report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf',
        mimetype='application/pdf'
    )

# EXISTING ROUTES (keeping your original functionality)
@app.route('/lca-tool')
def lca_tool():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard/lca_tool.html', username=session['username'])

@app.route('/custom-products')
def custom_products():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard/custom_products.html', username=session['username'])

@app.route('/calculate-lca', methods=['POST'])
def calculate_lca():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'})

    try:
        data = request.get_json()
        results = lca_calculator.calculate_lca(data)

        if results:
            assessment_data = {
                'user_id': session['user_id'],
                'input_data': data,
                'results': results,
                'created_at': datetime.utcnow(),
                'product_name': f"{data.get('product', 'Unknown')} - {data.get('route', 'Unknown')}"
            }

            assessment_id = mongo.db.assessments.insert_one(assessment_data).inserted_id
            results['assessment_id'] = str(assessment_id)

            return jsonify({'success': True, 'results': results})
        else:
            return jsonify({'success': False, 'message': 'Calculation failed'})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/compare-routes', methods=['POST'])
def compare_routes():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'})

    try:
        data = request.get_json()

        conventional_data = data.copy()
        conventional_data['route'] = 'conventional'
        conventional_results = lca_calculator.calculate_lca(conventional_data)

        recycled_data = data.copy()
        recycled_data['route'] = 'recycled'
        recycled_results = lca_calculator.calculate_lca(recycled_data)

        comparison = {
            'conventional': conventional_results,
            'recycled': recycled_results,
            'comparison': {
                'emissions_reduction': round(
                    ((conventional_results['co2_emissions'] - recycled_results['co2_emissions']) 
                     / conventional_results['co2_emissions']) * 100, 1),
                'cost_difference': round(
                    recycled_results['manufacturing_cost'] - conventional_results['manufacturing_cost'], 2),
                'quality_difference': round(
                    recycled_results['quality_score'] - conventional_results['quality_score'], 1)
            }
        }

        return jsonify({'success': True, 'comparison': comparison})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/reports')
def reports():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    assessments = list(mongo.db.assessments.find({'user_id': user_id})
                      .sort('created_at', -1))

    return render_template('dashboard/reports.html', 
                         username=session['username'], 
                         assessments=assessments)

@app.route('/download-report/<assessment_id>')
def download_report(assessment_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    try:
        assessment = mongo.db.assessments.find_one({
            '_id': ObjectId(assessment_id),
            'user_id': session['user_id']
        })

        if not assessment:
            flash('Report not found', 'error')
            return redirect(url_for('reports'))

        # Generate PDF report
        buffer = io.BytesIO()
        p = canvas.Canvas(buffer, pagesize=letter)

        # Header
        p.setFont("Helvetica-Bold", 16)
        p.drawString(50, 750, "LCA Tool - Environmental Impact Report")

        p.setFont("Helvetica", 12)
        p.drawString(50, 720, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        p.drawString(50, 700, f"Product: {assessment['product_name']}")

        # Results
        y_pos = 660
        results = assessment['results']

        p.setFont("Helvetica-Bold", 14)
        p.drawString(50, y_pos, "Environmental Impact Assessment")
        y_pos -= 30

        p.setFont("Helvetica", 11)
        metrics = [
            ('CO2 Emissions', f"{results['co2_emissions']} kg"),
            ('Energy Consumption', f"{results['energy_consumption']} kWh"),
            ('Water Usage', f"{results['water_usage']} L"),
            ('Material Mass', f"{results['material_mass']} kg"),
            ('Manufacturing Cost', f"${results['manufacturing_cost']}"),
            ('Recycled Content', f"{results['recycled_content']}%"),
            ('Recyclability', f"{results['recyclability']}%"),
            ('Quality Score', f"{results['quality_score']}")
        ]

        for metric, value in metrics:
            p.drawString(50, y_pos, f"{metric}: {value}")
            y_pos -= 20

        # Recommendations
        y_pos -= 20
        p.setFont("Helvetica-Bold", 14)
        p.drawString(50, y_pos, "AI-Powered Recommendations")
        y_pos -= 20

        p.setFont("Helvetica", 10)
        for i, rec in enumerate(results.get('recommendations', []), 1):
            if y_pos < 100:
                p.showPage()
                y_pos = 750

            p.drawString(50, y_pos, f"{i}. {rec['category']}: {rec['suggestion']}")
            y_pos -= 15
            p.drawString(70, y_pos, f"   Impact: {rec['impact']} | Savings: {rec['savings']}")
            y_pos -= 25

        p.save()
        buffer.seek(0)

        return send_file(
            buffer,
            as_attachment=True,
            download_name=f"LCA_Report_{assessment_id}.pdf",
            mimetype='application/pdf'
        )

    except Exception as e:
        flash(f'Error generating report: {str(e)}', 'error')
        return redirect(url_for('reports'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
