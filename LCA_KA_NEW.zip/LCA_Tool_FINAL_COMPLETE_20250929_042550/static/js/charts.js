let mainChart = null;
let impactChart = null;
let productChart = null;
let currentDataType = 'comparison';
let currentChartType = 'pie';

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    setupEventListeners();
    loadInitialData();
});

function initializeCharts() {
    // Main chart initialization
    const mainCtx = document.getElementById('mainChart').getContext('2d');
    mainChart = new Chart(mainCtx, {
        type: 'pie',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40',
                    '#FF6384',
                    '#C9CBCF'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += context.parsed + ' assessments';
                            return label;
                        }
                    }
                }
            }
        }
    });
    
    // Impact comparison chart initialization
    const impactCtx = document.getElementById('impactChart').getContext('2d');
    impactChart = new Chart(impactCtx, {
        type: 'bar',
        data: {
            labels: ['CO2 Emissions (kg)', 'Energy Usage (kWh)', 'Water Usage (L)', 'Manufacturing Cost ($)'],
            datasets: [{
                label: 'Conventional',
                data: [0, 0, 0, 0],
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }, {
                label: 'Recycled',
                data: [0, 0, 0, 0],
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += context.parsed.y.toLocaleString();
                            return label;
                        }
                    }
                }
            }
        }
    });
    
    // Product distribution chart initialization
    const productCtx = document.getElementById('productChart').getContext('2d');
    productChart = new Chart(productCtx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40'
                ],
                borderWidth: 3,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        padding: 15,
                        usePointStyle: true
                    }
                }
            }
        }
    });
}

function setupEventListeners() {
    // Data type buttons
    document.getElementById('showConventional').addEventListener('click', () => {
        setActiveButton('data', 'showConventional');
        currentDataType = 'conventional';
        updateChartTitle('Conventional Products Analysis');
        loadChartData();
    });
    
    document.getElementById('showRecycled').addEventListener('click', () => {
        setActiveButton('data', 'showRecycled');
        currentDataType = 'recycled';
        updateChartTitle('Recycled Products Analysis');
        loadChartData();
    });
    
    document.getElementById('showComparison').addEventListener('click', () => {
        setActiveButton('data', 'showComparison');
        currentDataType = 'comparison';
        updateChartTitle('Products Comparison Analysis');
        loadComparisonData();
    });
    
    // Chart type buttons
    document.getElementById('chartTypePie').addEventListener('click', () => {
        setActiveButton('chart', 'chartTypePie');
        currentChartType = 'pie';
        updateChartType();
    });
    
    document.getElementById('chartTypeBar').addEventListener('click', () => {
        setActiveButton('chart', 'chartTypeBar');
        currentChartType = 'bar';
        updateChartType();
    });
    
    document.getElementById('chartTypeLine').addEventListener('click', () => {
        setActiveButton('chart', 'chartTypeLine');
        currentChartType = 'line';
        updateChartType();
    });
}

function setActiveButton(group, activeId) {
    // Remove active class from all buttons in the group
    if (group === 'data') {
        ['showConventional', 'showRecycled', 'showComparison'].forEach(id => {
            document.getElementById(id).classList.remove('active');
        });
    } else if (group === 'chart') {
        ['chartTypePie', 'chartTypeBar', 'chartTypeLine'].forEach(id => {
            document.getElementById(id).classList.remove('active');
        });
    }
    
    // Add active class to clicked button
    document.getElementById(activeId).classList.add('active');
}

function showLoading(show) {
    const loadingElement = document.getElementById('chartLoading');
    const chartElement = document.getElementById('mainChart');
    
    if (loadingElement && chartElement) {
        loadingElement.style.display = show ? 'block' : 'none';
        chartElement.style.display = show ? 'none' : 'block';
    }
}

function loadInitialData() {
    loadComparisonData();
    loadProductDistribution();
}

async function loadChartData() {
    showLoading(true);
    try {
        const response = await fetch(`/api/chart-data/${currentDataType}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            console.error('Error loading data:', data.error);
            showError('Error loading chart data: ' + data.error);
            return;
        }
        
        // Update main chart based on current data type
        if (data.route_distribution && data.route_distribution.labels.length > 0) {
            mainChart.data.labels = data.route_distribution.labels;
            mainChart.data.datasets[0].data = data.route_distribution.data;
        } else {
            mainChart.data.labels = ['No Data'];
            mainChart.data.datasets[0].data = [1];
        }
        
        mainChart.update('active');
        
        // Update statistics
        updateStatistics(data);
        
    } catch (error) {
        console.error('Error fetching chart data:', error);
        showError('Network error loading data');
    } finally {
        showLoading(false);
    }
}

async function loadComparisonData() {
    showLoading(true);
    try {
        const response = await fetch('/api/comparison-data');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            console.error('Error loading comparison data:', data.error);
            showError('Error loading comparison data: ' + data.error);
            return;
        }
        
        // Update main chart with comparison
        const totalConventional = data.conventional ? data.conventional.count : 0;
        const totalRecycled = data.recycled ? data.recycled.count : 0;
        
        if (totalConventional === 0 && totalRecycled === 0) {
            mainChart.data.labels = ['No Data Available'];
            mainChart.data.datasets[0].data = [1];
        } else {
            mainChart.data.labels = ['Conventional', 'Recycled'];
            mainChart.data.datasets[0].data = [totalConventional, totalRecycled];
        }
        
        mainChart.update('active');
        
        // Update impact chart
        if (data.conventional && data.recycled) {
            impactChart.data.datasets[0].data = [
                data.conventional.avg_co2 || 0,
                data.conventional.avg_energy || 0,
                (data.conventional.avg_cost || 0) / 100, // Scale cost for better visualization
                data.conventional.total_co2 || 0
            ];
            
            impactChart.data.datasets[1].data = [
                data.recycled.avg_co2 || 0,
                data.recycled.avg_energy || 0,
                (data.recycled.avg_cost || 0) / 100,
                data.recycled.total_co2 || 0
            ];
        }
        
        impactChart.update('active');
        
        // Update statistics cards
        updateComparisonStatistics(data);
        
    } catch (error) {
        console.error('Error fetching comparison data:', error);
        showError('Network error loading comparison data');
    } finally {
        showLoading(false);
    }
}

async function loadProductDistribution() {
    try {
        const response = await fetch('/api/product-distribution');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            console.error('Error loading product distribution:', data.error);
            return;
        }
        
        // Update product chart
        if (data.labels && data.labels.length > 0) {
            productChart.data.labels = data.labels;
            productChart.data.datasets[0].data = data.counts;
        } else {
            productChart.data.labels = ['No Products'];
            productChart.data.datasets[0].data = [1];
        }
        
        productChart.update('active');
        
    } catch (error) {
        console.error('Error fetching product distribution:', error);
    }
}

function updateChartType() {
    // Destroy existing chart and create new one with different type
    const config = mainChart.config;
    const data = mainChart.data;
    
    mainChart.destroy();
    
    const ctx = document.getElementById('mainChart').getContext('2d');
    
    // Update configuration for new chart type
    config.type = currentChartType;
    
    // Adjust options based on chart type
    if (currentChartType === 'bar') {
        config.options.scales = {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString();
                    }
                }
            }
        };
        config.options.plugins.legend.position = 'top';
    } else if (currentChartType === 'line') {
        config.options.scales = {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString();
                    }
                }
            }
        };
        config.options.elements = {
            line: {
                tension: 0.4
            }
        };
        config.options.plugins.legend.position = 'top';
    } else {
        delete config.options.scales;
        delete config.options.elements;
        config.options.plugins.legend.position = 'bottom';
    }
    
    mainChart = new Chart(ctx, {
        type: currentChartType,
        data: data,
        options: config.options
    });
}

function updateChartTitle(title) {
    const titleElement = document.getElementById('chartTitle');
    if (titleElement) {
        titleElement.textContent = title;
    }
}

function updateStatistics(data) {
    const totalElement = document.getElementById('totalAssessments');
    if (totalElement && data.total_assessments !== undefined) {
        totalElement.textContent = data.total_assessments;
    }
}

function updateComparisonStatistics(data) {
    const totalElement = document.getElementById('totalAssessments');
    const co2ReductionElement = document.getElementById('co2Reduction');
    const energySavingsElement = document.getElementById('energySavings');
    const costImpactElement = document.getElementById('costImpact');
    
    if (totalElement) {
        const total = (data.conventional ? data.conventional.count : 0) + 
                     (data.recycled ? data.recycled.count : 0);
        totalElement.textContent = total;
    }
    
    if (co2ReductionElement && data.improvement) {
        co2ReductionElement.textContent = `${data.improvement.co2_reduction || 0}%`;
    }
    
    if (energySavingsElement && data.improvement) {
        energySavingsElement.textContent = `${data.improvement.energy_reduction || 0}%`;
    }
    
    if (costImpactElement && data.improvement) {
        const costDiff = data.improvement.cost_difference || 0;
        costImpactElement.textContent = `$${costDiff > 0 ? '+' : ''}${costDiff}`;
    }
}

function showError(message) {
    // Simple error display - you can enhance this with better UI
    console.error(message);
    
    // Try to show in a more user-friendly way if possible
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${message}`;
    errorDiv.style.position = 'fixed';
    errorDiv.style.top = '20px';
    errorDiv.style.right = '20px';
    errorDiv.style.zIndex = '9999';
    errorDiv.style.maxWidth = '400px';
    
    document.body.appendChild(errorDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.parentNode.removeChild(errorDiv);
        }
    }, 5000);
}

function downloadReport(reportType) {
    // Show loading state
    const button = event.target;
    const originalHTML = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    button.disabled = true;
    
    // Create download URL
    const downloadUrl = `/download-visualization-report/${reportType}`;
    
    // Create temporary link and trigger download
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = '';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Reset button after delay
    setTimeout(() => {
        button.innerHTML = originalHTML;
        button.disabled = false;
    }, 3000);
}

// Utility function to format numbers
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Add smooth animations
Chart.defaults.animation.duration = 1000;
Chart.defaults.animation.easing = 'easeInOutQuart';
