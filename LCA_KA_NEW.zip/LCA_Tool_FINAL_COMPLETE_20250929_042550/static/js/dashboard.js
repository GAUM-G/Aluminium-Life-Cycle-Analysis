// LCA Tool - Dashboard JavaScript

document.addEventListener('DOMContentLoaded', () => {
    console.log('📊 Dashboard JavaScript loaded');

    // Time selector buttons
    const timeButtons = document.querySelectorAll('.time-btn');
    timeButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            // Remove active class from all buttons
            timeButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            e.target.classList.add('active');

            const period = e.target.dataset.period;
            console.log(`Time period selected: ${period} days`);

            // Update insights data based on selected period
            updateInsights(period);
        });
    });
});

function updateInsights(period) {
    // This would normally fetch data from the server
    // For now, we'll just log the period change
    console.log(`Updating insights for ${period} day period`);
}