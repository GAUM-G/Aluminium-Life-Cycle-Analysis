// LCA Tool - LCA Assessment JavaScript

let currentResults = null;

document.addEventListener('DOMContentLoaded', () => {
    console.log('🧮 LCA Tool JavaScript loaded');

    // Handle product type change
    const productSelect = document.getElementById('product');
    if (productSelect) {
        productSelect.addEventListener('change', (e) => {
            updateDimensionsForm(e.target.value);
        });
    }

    // Handle LCA form submission
    const lcaForm = document.getElementById('lcaForm');
    if (lcaForm) {
        lcaForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('🧮 LCA form submitted');

            try {
                showLoading('Computing LCA assessment...');

                const formData = FormHandler.serialize(lcaForm);
                console.log('📤 Sending LCA data:', formData);

                const response = await API.post('/calculate-lca', formData);
                console.log('📥 LCA response:', response);

                if (response.success) {
                    currentResults = response.results;
                    displayResults(response.results);
                    showMessage('LCA assessment completed successfully!', 'success');
                } else {
                    throw new Error(response.message || 'LCA calculation failed');
                }

            } catch (error) {
                console.error('❌ LCA calculation error:', error);
                showMessage(error.message || 'LCA calculation failed. Please try again.', 'error');
            } finally {
                hideLoading();
            }
        });
    }

    // Handle route comparison
    const compareBtn = document.getElementById('compareBtn');
    if (compareBtn) {
        compareBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('⚖️ Route comparison requested');

            try {
                showLoading('Comparing production routes...');

                const formData = FormHandler.serialize(lcaForm);
                console.log('📤 Sending comparison data:', formData);

                const response = await API.post('/compare-routes', formData);
                console.log('📥 Comparison response:', response);

                if (response.success) {
                    displayComparison(response.comparison);
                    showMessage('Route comparison completed!', 'success');
                } else {
                    throw new Error(response.message || 'Route comparison failed');
                }

            } catch (error) {
                console.error('❌ Route comparison error:', error);
                showMessage(error.message || 'Route comparison failed. Please try again.', 'error');
            } finally {
                hideLoading();
            }
        });
    }

    // Handle results tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const tabName = e.target.dataset.tab;
            switchTab(tabName);
        });
    });
});

function updateDimensionsForm(productType) {
    // Hide all dimension groups
    document.querySelectorAll('.dimensions-group').forEach(group => {
        group.style.display = 'none';
    });

    // Show relevant dimension group
    if (productType === 'aluminium_pipe') {
        document.getElementById('pipesDimensions').style.display = 'block';
        document.getElementById('dimensionsTitle').textContent = 'Pipe Dimensions';
    } else if (productType === 'aluminium_sheet') {
        document.getElementById('sheetDimensions').style.display = 'block';
        document.getElementById('dimensionsTitle').textContent = 'Sheet Dimensions';
    } else if (productType === 'custom') {
        document.getElementById('customDimensions').style.display = 'block';
        document.getElementById('dimensionsTitle').textContent = 'Custom Product Dimensions';
    }
}

function displayResults(results) {
    // Show results section
    const resultsSection = document.getElementById('resultsSection');
    if (resultsSection) {
        resultsSection.style.display = 'block';
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    // Update result values
    const resultElements = {
        'co2Result': results.co2_emissions + ' kg',
        'energyResult': results.energy_consumption + ' kWh',
        'waterResult': results.water_usage + ' L',
        'massResult': results.material_mass + ' kg',
        'costResult': '$' + results.manufacturing_cost,
        'recycledResult': results.recycled_content + '%',
        'qualityResult': results.quality_score,
        'wasteResult': results.waste_generation + ' kg'
    };

    Object.entries(resultElements).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    });

    // Display recommendations
    displayRecommendations(results.recommendations);
}

function displayRecommendations(recommendations) {
    const container = document.getElementById('recommendationsContent');
    if (!container || !recommendations) return;

    container.innerHTML = recommendations.map(rec => `
        <div class="recommendation-item">
            <div class="rec-header">
                <span class="rec-category">${rec.category}</span>
                <span class="rec-impact impact-${rec.impact.toLowerCase()}">${rec.impact}</span>
            </div>
            <p class="rec-suggestion">${rec.suggestion}</p>
            <div class="rec-savings">
                <i class="fas fa-leaf"></i>
                ${rec.savings}
            </div>
        </div>
    `).join('');
}

function displayComparison(comparison) {
    // Switch to comparison tab
    switchTab('comparison');

    const container = document.getElementById('comparisonContent');
    if (!container) return;

    container.innerHTML = `
        <div class="comparison-grid">
            <div class="comparison-card">
                <h4>Conventional Route</h4>
                <div class="comparison-metrics">
                    <div class="comparison-metric">
                        <span class="metric-label">CO₂ Emissions</span>
                        <span class="metric-value">${comparison.conventional.co2_emissions} kg</span>
                    </div>
                    <div class="comparison-metric">
                        <span class="metric-label">Cost</span>
                        <span class="metric-value">$${comparison.conventional.manufacturing_cost}</span>
                    </div>
                    <div class="comparison-metric">
                        <span class="metric-label">Energy</span>
                        <span class="metric-value">${comparison.conventional.energy_consumption} kWh</span>
                    </div>
                </div>
            </div>

            <div class="comparison-card">
                <h4>Recycled Route</h4>
                <div class="comparison-metrics">
                    <div class="comparison-metric">
                        <span class="metric-label">CO₂ Emissions</span>
                        <span class="metric-value">${comparison.recycled.co2_emissions} kg</span>
                    </div>
                    <div class="comparison-metric">
                        <span class="metric-label">Cost</span>
                        <span class="metric-value">$${comparison.recycled.manufacturing_cost}</span>
                    </div>
                    <div class="comparison-metric">
                        <span class="metric-label">Energy</span>
                        <span class="metric-value">${comparison.recycled.energy_consumption} kWh</span>
                    </div>
                </div>
            </div>

            <div class="comparison-summary">
                <h4>Environmental Impact Comparison</h4>
                <div class="summary-metrics">
                    <div class="summary-item">
                        <span class="summary-label">Emissions Reduction</span>
                        <span class="summary-value positive">${comparison.comparison.emissions_reduction}%</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">Cost Difference</span>
                        <span class="summary-value">${comparison.comparison.cost_difference > 0 ? '+' : ''}$${comparison.comparison.cost_difference}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function switchTab(tabName) {
    // Remove active class from all tabs and content
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    // Add active class to selected tab and content
    const selectedBtn = document.querySelector(`[data-tab="${tabName}"]`);
    const selectedContent = document.getElementById(`${tabName}Tab`);

    if (selectedBtn) selectedBtn.classList.add('active');
    if (selectedContent) selectedContent.classList.add('active');
}