// LCA Tool - Authentication JavaScript

document.addEventListener('DOMContentLoaded', () => {
    console.log('🔐 Auth JavaScript loaded');

    // Handle signup form
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('📝 Signup form submitted');

            try {
                const formData = FormHandler.serialize(signupForm);
                console.log('📤 Sending signup data:', formData);

                // Validate passwords match
                if (formData.password !== formData.confirmPassword) {
                    showMessage('Passwords do not match', 'error');
                    return;
                }

                showLoading('Creating your account...');

                const response = await API.post('/signup', formData);
                console.log('📥 Signup response:', response);

                if (response.success) {
                    showMessage('Account created successfully! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = '/dashboard';
                    }, 1500);
                } else {
                    throw new Error(response.message || 'Signup failed');
                }

            } catch (error) {
                console.error('❌ Signup error:', error);
                showMessage(error.message || 'Signup failed. Please try again.', 'error');
            } finally {
                hideLoading();
            }
        });
    }

    // Handle login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('🔑 Login form submitted');

            try {
                const formData = FormHandler.serialize(loginForm);
                console.log('📤 Sending login data:', formData);

                showLoading('Signing you in...');

                const response = await API.post('/login', formData);
                console.log('📥 Login response:', response);

                if (response.success) {
                    showMessage('Login successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = '/dashboard';
                    }, 1000);
                } else {
                    throw new Error(response.message || 'Login failed');
                }

            } catch (error) {
                console.error('❌ Login error:', error);
                showMessage(error.message || 'Login failed. Please try again.', 'error');
            } finally {
                hideLoading();
            }
        });
    }
});