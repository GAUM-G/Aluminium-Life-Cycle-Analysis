from pymongo import MongoClient

# Your corrected connection string
connection_string = "mongodb+srv://lca_admin:iy423WBcKxhZmAcP@lca-cluster.een843p.mongodb.net/lca_tool"

print("🧪 Testing corrected connection string...")
print(f"Connection: {connection_string}")

try:
    client = MongoClient(connection_string, serverSelectionTimeoutMS=10000)
    client.admin.command('ping')
    print("✅ SUCCESS: Authentication working!")
    
    # Test database access
    db = client.lca_tool
    print("✅ Database 'lca_tool' accessible")
    
    # Test basic operations
    test_collection = db.test
    result = test_collection.insert_one({"test": "connection working"})
    print(f"✅ Test document inserted with ID: {result.inserted_id}")
    
    # Clean up
    test_collection.delete_one({"_id": result.inserted_id})
    print("✅ Test document cleaned up")
    
    client.close()
    print("\n🎯 Connection string is working perfectly!")
    print("You can now use this in your LCA Tool project.")
    
except Exception as e:
    print(f"❌ FAILED: {e}")
    if "authentication failed" in str(e).lower():
        print("💡 Still getting auth error? Check if user exists in Atlas")
    elif "timeout" in str(e).lower():
        print("💡 Network issue? Check Network Access in Atlas")
