import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { useAppContext } from '../App';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { 
  Leaf, 
  Zap, 
  Droplets, 
  DollarSign, 
  TrendingDown, 
  TrendingUp, 
  Download,
  AlertTriangle,
  CheckCircle,
  Recycle
} from 'lucide-react';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export default function OutputPage() {
  const { currentAssessment, addReport } = useAppContext();
  const [activeTab, setActiveTab] = useState('lca');

  if (!currentAssessment) {
    return <div>No assessment data available</div>;
  }

  // Mock calculated data based on assessment
  const lcaData = {
    totalCO2: 6921.3,
    totalElectricity: 19035,
    totalWater: 7397,
    totalCost: 3348,
    stages: [
      { name: 'Casting', co2: 1350, electricity: 3500, cost: 450 },
      { name: 'Extrusion', co2: 2200, electricity: 6800, cost: 890 },
      { name: 'Quench', co2: 450, electricity: 1500, cost: 220 },
      { name: 'Hot', co2: 380, electricity: 1200, cost: 180 },
      { name: 'Finish', co2: 520, electricity: 1500, cost: 280 },
      { name: 'Aging/Heat', co2: 1821, electricity: 4535, cost: 1328 }
    ]
  };

  const comparisonData = {
    conventional: { co2: 6921.3, cost: 3348, quality: 85 },
    recycled: { co2: 4156.7, cost: 2895, quality: 82 }
  };

  const pieData = [
    { name: 'Casting', value: 1350, color: '#10b981' },
    { name: 'Extrusion', value: 2200, color: '#3b82f6' },
    { name: 'Quench', value: 450, color: '#f59e0b' },
    { name: 'Hot', value: 380, color: '#ef4444' },
    { name: 'Finish', value: 520, color: '#8b5cf6' },
    { name: 'Aging/Heat', value: 1821, color: '#06b6d4' }
  ];

  const sankeyData = lcaData.stages.map(stage => ({
    ...stage,
    efficiency: (stage.co2 / lcaData.totalCO2 * 100).toFixed(1)
  }));

  const handleDownloadReport = () => {
    addReport(currentAssessment);
    alert('Report added to your history and ready for download!');
  };

  const renderLCATab = () => (
    <div className="space-y-8">
      {/* Hero Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Leaf, label: 'Total CO₂', value: `${lcaData.totalCO2}`, unit: 'kg', color: 'from-red-500 to-red-600' },
          { icon: Zap, label: 'Total Electricity', value: `${lcaData.totalElectricity}`, unit: 'kWh', color: 'from-yellow-500 to-yellow-600' },
          { icon: Droplets, label: 'Total Water', value: `${lcaData.totalWater}`, unit: 'L', color: 'from-blue-500 to-blue-600' },
          { icon: DollarSign, label: 'Total Cost', value: `$${lcaData.totalCost}`, unit: 'USD', color: 'from-green-500 to-green-600' }
        ].map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${metric.color}`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">{metric.label}</p>
                      <p className="text-2xl">{metric.value}</p>
                      <p className="text-xs text-gray-500">{metric.unit}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Detailed Breakdown */}
      <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Lifecycle Stage Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lcaData.stages}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="co2" fill="#ef4444" name="CO₂ (kg)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderDecarbonizationTab = () => (
    <div className="space-y-6">
      <h3 className="text-xl mb-4">Decarbonization Opportunities</h3>
      
      {[
        {
          stage: 'Energy Source',
          potential: '40%',
          suggestion: 'Switch to renewable energy sources (solar/wind)',
          impact: 'High',
          icon: Zap
        },
        {
          stage: 'Material Route',
          potential: '35%',
          suggestion: 'Use recycled aluminum instead of primary production',
          impact: 'High',
          icon: Recycle
        },
        {
          stage: 'Process Optimization',
          potential: '15%',
          suggestion: 'Optimize extrusion process for energy efficiency',
          impact: 'Medium',
          icon: TrendingDown
        },
        {
          stage: 'Transportation',
          potential: '10%',
          suggestion: 'Implement local sourcing and shorter supply chains',
          impact: 'Low',
          icon: TrendingUp
        }
      ].map((item, index) => {
        const Icon = item.icon;
        return (
          <motion.div
            key={item.stage}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-green-100 rounded-xl">
                    <Icon className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="text-lg">{item.stage}</h4>
                      <Badge variant={item.impact === 'High' ? 'destructive' : item.impact === 'Medium' ? 'default' : 'secondary'}>
                        {item.impact} Impact
                      </Badge>
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        {item.potential} Reduction
                      </Badge>
                    </div>
                    <p className="text-gray-600">{item.suggestion}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );

  const renderComparisonsTab = () => (
    <div className="space-y-8">
      <h3 className="text-xl mb-6">Route Comparison: Conventional vs Recycled</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {[
          { metric: 'CO₂ Emissions (kg)', conv: comparisonData.conventional.co2, rec: comparisonData.recycled.co2, unit: 'kg' },
          { metric: 'Total Cost', conv: comparisonData.conventional.cost, rec: comparisonData.recycled.cost, unit: '$' },
          { metric: 'Quality Score', conv: comparisonData.conventional.quality, rec: comparisonData.recycled.quality, unit: '/100' }
        ].map((item) => {
          const isConventionalHigher = item.conv > item.rec;
          const difference = Math.abs(item.conv - item.rec);
          const percentageDiff = ((difference / Math.min(item.conv, item.rec)) * 100).toFixed(1);
          
          return (
            <Card key={item.metric} className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">{item.metric}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Conventional</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{item.unit}{item.conv}</span>
                      {isConventionalHigher && item.metric !== 'Quality Score' && (
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                      )}
                      {!isConventionalHigher && item.metric === 'Quality Score' && (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Recycled</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{item.unit}{item.rec}</span>
                      {!isConventionalHigher && item.metric !== 'Quality Score' && (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      )}
                      {isConventionalHigher && item.metric === 'Quality Score' && (
                        <AlertTriangle className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                  </div>
                  
                  <div className="pt-2 border-t">
                    <Badge variant="outline" className="text-xs">
                      {percentageDiff}% difference
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
              <p className="text-green-800">
                <strong>Recycled route reduces CO₂ emissions by 40%</strong> while maintaining acceptable quality standards.
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
              <p className="text-green-800">
                <strong>Cost savings of 13.5%</strong> make recycled route economically attractive.
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
              <p className="text-green-800">
                Consider quality requirements - 3-point difference may be acceptable for most applications.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderVisualizationTab = () => (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pie Chart */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle>CO₂ Distribution by Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Line Chart */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Process Flow Impact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={lcaData.stages}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="co2" stroke="#ef4444" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sankey-style visualization */}
      <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Material Flow Visualization</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sankeyData.map((stage, index) => (
              <div key={stage.name} className="flex items-center space-x-4">
                <div className="w-24 text-sm text-gray-600">{stage.name}</div>
                <div className="flex-1 bg-gray-200 rounded-full h-8 relative overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${stage.efficiency}%` }}
                    transition={{ duration: 1, delay: index * 0.2 }}
                    className="h-full bg-gradient-to-r from-red-400 to-red-600 rounded-full"
                  />
                  <div className="absolute inset-0 flex items-center justify-center text-white text-sm">
                    {stage.co2} kg ({stage.efficiency}%)
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderReportsTab = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h3 className="text-2xl mb-4">Complete Assessment Report</h3>
        <p className="text-gray-600 mb-8">Comprehensive analysis of your product's environmental impact</p>
      </div>

      {/* All sections combined */}
      <div className="space-y-12">
        <section>
          <h4 className="text-xl mb-4 flex items-center space-x-2">
            <Leaf className="h-5 w-5 text-green-600" />
            <span>Life Cycle Assessment</span>
          </h4>
          {renderLCATab()}
        </section>

        <section>
          <h4 className="text-xl mb-4 flex items-center space-x-2">
            <TrendingDown className="h-5 w-5 text-blue-600" />
            <span>Decarbonization Potential</span>
          </h4>
          {renderDecarbonizationTab()}
        </section>

        <section>
          <h4 className="text-xl mb-4 flex items-center space-x-2">
            <BarChart className="h-5 w-5 text-purple-600" />
            <span>Route Comparisons</span>
          </h4>
          {renderComparisonsTab()}
        </section>

        <div className="text-center pt-8">
          <Button
            onClick={handleDownloadReport}
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-3"
          >
            <Download className="mr-2 h-5 w-5" />
            Download Report (PDF)
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-8 text-center"
      >
        <h1 className="text-3xl mb-4">Assessment Results</h1>
        <p className="text-gray-600">
          Analysis for {currentAssessment.product.replace('-', ' ')} - {currentAssessment.route} route
        </p>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 mb-8">
          <TabsTrigger value="lca">LCA</TabsTrigger>
          <TabsTrigger value="decarbonization">Decarbonization</TabsTrigger>
          <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
          <TabsTrigger value="visualization">Visualization</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="lca">{renderLCATab()}</TabsContent>
        <TabsContent value="decarbonization">{renderDecarbonizationTab()}</TabsContent>
        <TabsContent value="comparisons">{renderComparisonsTab()}</TabsContent>
        <TabsContent value="visualization">{renderVisualizationTab()}</TabsContent>
        <TabsContent value="reports">{renderReportsTab()}</TabsContent>
      </Tabs>
    </div>
  );
}