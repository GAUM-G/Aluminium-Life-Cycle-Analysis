import React from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useAppContext } from '../App';
import { 
  FileText, 
  Download, 
  Eye, 
  Calendar, 
  Package, 
  Leaf,
  Clock
} from 'lucide-react';

export default function ViewReports() {
  const { reports, setCurrentAssessment, setCurrentPage } = useAppContext();

  // Mock reports for demonstration if no reports exist
  const mockReports = reports.length === 0 ? [
    {
      id: 'mock-1',
      product: 'aluminium-pipe',
      route: 'conventional',
      units: 100,
      bauxiteGrade: 'high',
      energySource: 'renewable',
      endOfLife: 'recycle',
      dimensions: { outerRadius: 0.1, innerRadius: 0.08, length: 2.0 },
      timestamp: '2024-01-15T10:30:00.000Z'
    },
    {
      id: 'mock-2',
      product: 'aluminium-sheet',
      route: 'recycled',
      units: 250,
      bauxiteGrade: 'medium',
      energySource: 'non-renewable',
      endOfLife: 'reuse',
      dimensions: { length: 1.0, width: 0.5, thickness: 0.01 },
      timestamp: '2024-01-10T14:20:00.000Z'
    },
    {
      id: 'mock-3',
      product: 'custom-heat-exchanger',
      route: 'conventional',
      units: 50,
      bauxiteGrade: 'high',
      energySource: 'renewable',
      endOfLife: 'recycle',
      dimensions: { length: 1.5, width: 0.8, thickness: 0.02 },
      timestamp: '2024-01-05T09:15:00.000Z',
      isCustom: true
    }
  ] : reports;

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getProductDisplayName = (product: string) => {
    if (product.startsWith('custom-')) {
      return product.replace('custom-', '').replace('-', ' ').toUpperCase();
    }
    return product.replace('-', ' ').toUpperCase();
  };

  const getRouteColor = (route: string) => {
    return route === 'recycled' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800';
  };

  const handleViewReport = (report: any) => {
    setCurrentAssessment(report);
    setCurrentPage('output');
  };

  const handleDownloadReport = (reportId: string) => {
    // Mock download functionality
    alert(`Downloading report ${reportId} as PDF...`);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-8"
      >
        <h1 className="text-3xl mb-4 text-center">Assessment Reports</h1>
        <p className="text-gray-600 text-center">
          Access and download your LCA assessment history
        </p>
      </motion.div>

      {mockReports.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center py-16"
        >
          <div className="mb-6">
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl text-gray-600 mb-2">No Reports Yet</h3>
            <p className="text-gray-500">
              Complete your first LCA assessment to see reports here
            </p>
          </div>
          <Button
            onClick={() => setCurrentPage('lca-assessment')}
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
          >
            Start New Assessment
          </Button>
        </motion.div>
      ) : (
        <div className="space-y-6">
          {mockReports.map((report, index) => (
            <motion.div
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className="p-3 bg-gradient-to-br from-blue-100 to-green-100 rounded-xl">
                        <Package className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg mb-2">
                          {getProductDisplayName(report.product)}
                          {report.isCustom && (
                            <Badge variant="outline" className="ml-2 text-purple-600 border-purple-600">
                              Custom
                            </Badge>
                          )}
                        </CardTitle>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{formatDate(report.timestamp)}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Package className="h-4 w-4" />
                            <span>{report.units} units</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewReport(report)}
                        className="group hover:bg-blue-50"
                      >
                        <Eye className="h-4 w-4 mr-2 group-hover:text-blue-600" />
                        View
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDownloadReport(report.id)}
                        className="group hover:bg-green-50"
                      >
                        <Download className="h-4 w-4 mr-2 group-hover:text-green-600" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">Route</p>
                      <Badge className={getRouteColor(report.route)}>
                        {report.route}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">Energy Source</p>
                      <div className="flex items-center space-x-1">
                        {report.energySource === 'renewable' ? (
                          <Leaf className="h-4 w-4 text-green-500" />
                        ) : (
                          <Leaf className="h-4 w-4 text-orange-500" />
                        )}
                        <span className="text-sm capitalize">{report.energySource}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">End of Life</p>
                      <span className="text-sm capitalize">{report.endOfLife}</span>
                    </div>
                    
                    <div className="space-y-2">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">Assessment Type</p>
                      <span className="text-sm">
                        {report.isCustom ? 'Custom Product' : 'Standard Product'}
                      </span>
                    </div>
                  </div>

                  {/* Dimensions Preview */}
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Dimensions</p>
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(report.dimensions).map(([key, value]) => (
                        <Badge key={key} variant="secondary" className="text-xs">
                          {key}: {typeof value === 'number' ? value.toFixed(3) : value}
                          {typeof value === 'number' && key !== 'density' ? 'm' : ''}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-2 bg-red-50 rounded-lg">
                        <p className="text-xs text-red-600">Est. CO₂</p>
                        <p className="font-semibold text-red-700">
                          {Math.floor(Math.random() * 5000 + 2000)} kg
                        </p>
                      </div>
                      <div className="p-2 bg-yellow-50 rounded-lg">
                        <p className="text-xs text-yellow-600">Est. Energy</p>
                        <p className="font-semibold text-yellow-700">
                          {Math.floor(Math.random() * 15000 + 10000)} kWh
                        </p>
                      </div>
                      <div className="p-2 bg-green-50 rounded-lg">
                        <p className="text-xs text-green-600">Est. Cost</p>
                        <p className="font-semibold text-green-700">
                          ${Math.floor(Math.random() * 2000 + 1500)}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Summary Stats */}
      {mockReports.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12"
        >
          <Card className="bg-gradient-to-br from-blue-50 to-green-50 border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-center">Assessment Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="p-3 bg-blue-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>
                  <p className="text-2xl font-semibold">{mockReports.length}</p>
                  <p className="text-sm text-gray-600">Total Reports</p>
                </div>
                
                <div>
                  <div className="p-3 bg-green-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                    <Leaf className="h-6 w-6 text-green-600" />
                  </div>
                  <p className="text-2xl font-semibold">
                    {mockReports.filter(r => r.route === 'recycled').length}
                  </p>
                  <p className="text-sm text-gray-600">Recycled Route</p>
                </div>
                
                <div>
                  <div className="p-3 bg-purple-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                    <Package className="h-6 w-6 text-purple-600" />
                  </div>
                  <p className="text-2xl font-semibold">
                    {mockReports.filter(r => r.isCustom).length}
                  </p>
                  <p className="text-sm text-gray-600">Custom Products</p>
                </div>
                
                <div>
                  <div className="p-3 bg-orange-100 rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                    <Clock className="h-6 w-6 text-orange-600" />
                  </div>
                  <p className="text-2xl font-semibold">
                    {Math.floor((Date.now() - new Date(mockReports[mockReports.length - 1]?.timestamp || Date.now()).getTime()) / (1000 * 60 * 60 * 24))}
                  </p>
                  <p className="text-sm text-gray-600">Days Since Last</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}